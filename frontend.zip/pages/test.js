import React from "react";
import Test from "../src/Test";

export default function test() {
  return <Test />;
}
